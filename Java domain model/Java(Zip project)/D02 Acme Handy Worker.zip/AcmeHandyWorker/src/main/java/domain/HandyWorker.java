
package domain;

public class HandyWorker extends DomainEntity {

	private String	make;	//NotBlank


	public String getMake() {
		return this.make;
	}

	public void setMake(final String make) {
		this.make = make;
	}

}
