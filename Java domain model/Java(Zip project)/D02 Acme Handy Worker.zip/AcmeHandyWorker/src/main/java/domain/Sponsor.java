
package domain;

public class Sponsor extends DomainEntity {

}
