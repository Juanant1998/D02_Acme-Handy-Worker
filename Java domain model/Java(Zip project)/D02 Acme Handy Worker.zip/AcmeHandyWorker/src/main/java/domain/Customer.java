
package domain;

public class Customer extends DomainEntity {

}
