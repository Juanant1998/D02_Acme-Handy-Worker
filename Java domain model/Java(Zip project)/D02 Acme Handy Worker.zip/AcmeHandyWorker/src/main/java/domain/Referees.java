
package domain;

public class Referees extends DomainEntity {

}
